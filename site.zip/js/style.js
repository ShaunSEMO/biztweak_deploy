/* ------Consultant page --------*/
$(document).ready(function() {

	$( ".completed-box" ).click(function() {
		$(".completed-area").show("slow");
		$(".incompleted-area").hide();
	});

	$( ".incomplete-box" ).click(function() {
		$(".incompleted-area").show("slow");
		$(".completed-area").hide();
	});

	/* ------Entrepreneur page --------*/

	
});