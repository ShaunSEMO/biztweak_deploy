<?php
if (isset($_POST['save'])) {
    echo 'success';
}

?>
